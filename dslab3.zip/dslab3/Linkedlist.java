/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package linkedlist;

/**
 *
 * @author ESHOP
 */
public class Linkedlist {
     int size=0;
    public class Node{
        int Data;
        Node next;
        Node(int data){
            this.Data=data;
            this.next=null;
            size++;
        }
    }
  private Node head;
  private Node tail=null;
    Linkedlist(){
        head=tail;
    }
    public void InsertAtStart(int data){
        Node newNode=new Node(data);
        if(head==null){
            head=newNode;
            return;
        }
        newNode.next=head;
        head=newNode;
    }   
    public void InsertAtlast(int data){
        Node newNode=new Node(data);
        if(head==null){
            head=newNode;
            return;
        }
      Node current=head;
      while(current.next!=null){
          current=current.next;
      }
         current.next=newNode;       
    }
    public void insertAtMiddle(int data, int pos){
        Node newNode=new Node(data);
        if(pos==0){
            newNode.next=head;
            head=newNode;
        }
        else{
            Node current=head;
            for(int i=0; i<pos-1; i++){
                current=current.next;
            }
            newNode.next=current.next;
            current.next=newNode;
        }
    }

        
    public void Displayall(){
        Node current=head;
        while(current!=null){
            System.out.println(current.Data); 
           current= current.next;
        }   
    }
    
    public void DeleteAtStart(){
       if(head==null){
           System.out.println("list is empty");
           return;
       } 
       Node current =head;
       head=current.next;
       size--;
       
    }
    public void deleteatlast(){
         if(head==null){
           System.out.println("list is empty");
           return;     
    }
         if(head.next==null){
             head=null;
             return;
         }
            Node slnode=head;
            Node lnode=head.next;
            while(lnode.next!=null){
                lnode=lnode.next;
                slnode=slnode.next;
            }
            slnode.next=null;
            size--;
    }
    public void deletbyvalue(int value){
       if (head == null) {
            System.out.println("List is empty.");
            return;
        }

        if (head.Data == value) {
            head = head.next;
            return;
        }

        Node temp = head;
        while (temp.next != null && temp.next.Data != value) {
            temp = temp.next;
        }

        if (temp.next == null) {
            System.out.println("Value not found in the list.");
        } else {
            temp.next = temp.next.next;
        }
    
    }
    public void search(int key) {
        Node temp = head;
        int position = 0;

        while (temp != null) {
            if (temp.Data == key) {
                System.out.println("Value " + key + " found at position " + position);
                return;
            }
            temp = temp.next;
            position++;
        }

        System.out.println("Value " + key + " not found.");
    }

   
    public void reverse() {
        Node prev = null;
        Node current = head;
        Node next;

        while (current != null) {
            next = current.next;
            current.next = prev;
            prev = current;
            current = next;
        }

        head = prev;
    }

    
    public int countNodes() {
        Node temp = head;
        int count = 0;

        while (temp != null) {
            count++;
            temp = temp.next;
        }

        return count;
    }
            
    public static void main(String[] args) {
        Linkedlist list=new Linkedlist(); 
        list.InsertAtStart(1);
         list.InsertAtStart(2);
         list.InsertAtlast(3);
         list.InsertAtlast(4);
        list.Displayall();
        list.DeleteAtStart();
        list.InsertAtStart(5);
         list.InsertAtlast(7);
       list.insertAtMiddle(5, 3);
       list.deletbyvalue(3);
       list.search(4);
       list.reverse();
       list.Displayall();
        list.countNodes();
      
      
    }
    
}
