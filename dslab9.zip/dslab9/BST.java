/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package binaryt;
import java.util.*;
/**
 *
 * @author ESHOP
 */
public class BST {
      Node root;
      public BST(int value){
          root=new Node(value);
      }
      public void insert(int value){
        Node newnode=new Node(value);
         if(root==null){
             root=newnode;
         }else{
        root=insertrecurssion(root,value);
         }
    
    }
    public Node insertrecurssion(Node root,int value){
        if (root==null){
            return new Node(value);
        }
        else if(value < root.value){
            root.left=insertrecurssion(root.left,value);
        }
        else if(value > root.value){
            root.right=insertrecurssion(root.right,value);
        }
        return root;
        
    }
       public int countsNode(){
           return counts(root);
       }
       public int counts(Node node){
           if(node==null){
               return 0;
           }
           return 1+counts(node.left)+counts(node.right);
       }
       public void inorder(Node root){
           if(root==null){
               return;
           }
           inorder(root.left);
           System.out.println(root.value);
           inorder(root.right);
       }
       public void preorder(Node root){
           if(root==null){
               return;
           }
           System.out.println(root.value);
           preorder(root.left);
           preorder(root.right);
       }
       public void postorder(Node root){
           if(root==null){
               return;
           }
           postorder(root.left);
           postorder(root.right);
           System.out.println(root.value);
       }
       public void levelorder(Node root){
           if(root==null){
               return;
           }
           Queue<Node> queue= new LinkedList();
           queue.add(root);
           while(!queue.isEmpty()){
               Node current=queue.poll();
               System.out.println(current.value);
               if(current.left!=null){
                   queue.add(current.left);
               }
               if(current.right!=null){
                   queue.add(current.right);  
               }
           }
       }
      public boolean search(int value) {
        return searchRec(root, value);
    }

   
    private boolean searchRec(Node root, int value) {
        if (root == null) {
            return false;
        }
        if (root.value == value) {
            return true;
        }
        if (value < root.value) {
            return searchRec(root.left, value);
        } else {
            return searchRec(root.right, value);
        }
    }

      
       
    public static void main(String[] args) {
        // TODO code application logic here
       BST bt = new BST(50); 
    bt.insert(23);
    bt.insert(67);        
    bt.insert(15);        
    bt.insert(34);

    System.out.println("Root value: " + bt.root.value);

    System.out.println("Total nodes in the tree: " + bt.countsNode());

    System.out.println("Inorder Traversal:");
    bt.inorder(bt.root);

    System.out.println("Level Order Traversal:");
    bt.levelorder(bt.root);
        
    }

   
    
}
