/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package binarytree;
import java.util.*;
/**
 *
 * @author ESHOP
 */
public class binarytree {

    
  static class Node{
    int value;
    Node left;
    Node right;
    
    Node(int value){
        this.value=value;
        this.left=null;
        this.right=null;
    }
    }
   static class boperation{
        Node root;
    
    private void insert(int value){
         Node newnode=new Node(value);
         if(root==null){
             root=newnode;
         }else{
        root=insertRecurssion(root,value);
         }
    }
    private Node insertRecurssion(Node current, int value){
        if (current == null) {
                return new Node(value);
            }
        if(value< current.value){
            current.left=insertRecurssion(current.left, value);
            
        }
       else if(value > current.value){
            current.right=insertRecurssion(current.right, value);  
        }
        return current;
    }
    
     private int countsNodes(){
         return countNodesRecursive(root);
     }
     private int countNodesRecursive(Node node) {
            if (node == null) {
                return 0;
            }
            return 1 + countNodesRecursive(node.left) + countNodesRecursive(node.right);
        }
        public static void preorder(Node root){
        if(root==null){
            return;
        }
        System.out.println(root.value+" ");
        preorder(root.left);
        preorder(root.right);
    }
     public static void inorder(Node root){
        if(root==null){
            return;
        }
        inorder(root.left);
        System.out.println(root.value+" ");
        inorder(root.right);
    }
      public void postorder(Node node) {
            if (node == null) return;
            postorder(node.left);
            postorder(node.right);
            System.out.print(node.value + " ");
        }
      public void levelorder(){
          if(root==null){
              return;
          }
          Queue<Node> queue= new LinkedList();
          queue.add(root);
          
          while(!queue.isEmpty()){
              Node current=queue.poll();
              System.out.println(current.value);
              
              if(current.left!=null){
                  queue.add(current.left);
              }
              if(current.right!=null){
                  queue.add(current.right);
              }
          }
      }
      
     }
    public static void main(String[] args) {
        // TODO code application logic here
       boperation tree=new boperation();
        tree.insert(50);
        tree.insert(30);
        tree.insert(40);
        tree.insert(70);
        tree.insert(60);
        tree.insert(80);
        System.out.println(tree.countsNodes());
        
        tree.levelorder();
        tree.postorder(tree.root);
        tree.inorder(tree.root);
    
     
       
    }
    
}
