/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package bubblesort;

/**
 *
 * @author ESHOP
 */
public class Bubblesort {

      int arr[]=new int[5];
      public void sorting(int arr[]){
     int n=arr.length;
      for(int i=0; i<=n-1; i++){
          for(int j=0; j<n-i-1; i++){
              if(arr[j]>arr[j+1]){
                  
              int temp=arr[j];
              arr[j]=arr[j+1];
              arr[j+1]=temp;
          }
          }}  
}
      public void display(int arr[]){
          for(int i=0; i<arr.length; i++){
              System.out.println(arr[i]);
          }
              
      }
    public static void main(String[] args) {
        // TODO code application logic here
        int arr[]={4,1,3,2};
        Bubblesort b=new Bubblesort();
        b.sorting(arr);
        b.display(arr);
    }
    
}
