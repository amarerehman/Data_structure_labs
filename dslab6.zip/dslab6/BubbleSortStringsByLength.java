/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package string;
import java.util.Arrays;


public class BubbleSortStringsByLength {
    // Method to sort an array of strings by their lengths
    public static void bubbleSortByLength(String[] arr) {
        int n = arr.length;
        boolean swapped;

        // Outer loop for each pass
        for (int i = 0; i < n - 1; i++) {
            swapped = false;

            // Inner loop for comparison and swapping
            for (int j = 0; j < n - i - 1; j++) {
                // Compare lengths of adjacent strings
                if (arr[j].length() > arr[j + 1].length()) {
                    // Swap the strings if out of order
                    String temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                    swapped = true;
                }
            }

            // If no swaps occurred, the array is sorted
            if (!swapped) {
                break;
            }
        }
    }

    // Main method to test the string sorting
    public static void main(String[] args) {
        String[] arr = {"apple", "pie", "banana", "cat"};

        System.out.println("Original Array:");
        System.out.println(Arrays.toString(arr));

        bubbleSortByLength(arr);

        System.out.println("\nSorted Array by Length:");
        System.out.println(Arrays.toString(arr));
    }
}